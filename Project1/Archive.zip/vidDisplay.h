//
//  vidDisplay.h
//  Project1
//
//  Created by DB on 2/5/23.
//

int displayLiveVideoFeed(cv::VideoCapture *capdev);

const std::string currentDateTime();
